import { normalizeGenericPaymentPayload, verifyGenericPaymentSignature } from '../shared/generic-adapter';
export const verifyTonSignature = verifyGenericPaymentSignature;
export const normalizeTonPayment = (payload: unknown, restaurantId: string) =>
  normalizeGenericPaymentPayload({ payload, restaurantId, provider: 'ton' });
