import type { NormalizedTransaction } from '../shared/types';
import { normalizeCieloPayment, verifyCieloSignature } from './cielo/adapter';
import { normalizeGetnetPayment, verifyGetnetSignature } from './getnet/adapter';
import { normalizeInfinitePayPayment, verifyInfinitePaySignature } from './infinitepay/adapter';
import { normalizePagBankPayment, verifyPagBankSignature } from './pagbank/adapter';
import { getRemainingProviderConfig, remainingPaymentProviders, type RemainingPaymentProvider } from './provider-config';
import { normalizeRedePayment, verifyRedeSignature } from './rede/adapter';
import { normalizeSafraPayPayment, verifySafraPaySignature } from './safrapay/adapter';
import { normalizeStonePayment, verifyStoneSignature } from './stone/adapter';
import { normalizeTonPayment, verifyTonSignature } from './ton/adapter';

type RemainingPaymentAdapter = {
  normalize: (payload: unknown, restaurantId: string) => NormalizedTransaction;
  verify: (rawBody: string, signature: string | undefined, secret: string | undefined) => boolean;
};

export { getRemainingProviderConfig, remainingPaymentProviders };
export type { RemainingPaymentProvider };

export const remainingPaymentAdapters: Record<RemainingPaymentProvider, RemainingPaymentAdapter> = {
  stone: { normalize: normalizeStonePayment, verify: verifyStoneSignature },
  pagbank: { normalize: normalizePagBankPayment, verify: verifyPagBankSignature },
  cielo: { normalize: normalizeCieloPayment, verify: verifyCieloSignature },
  getnet: { normalize: normalizeGetnetPayment, verify: verifyGetnetSignature },
  rede: { normalize: normalizeRedePayment, verify: verifyRedeSignature },
  ton: { normalize: normalizeTonPayment, verify: verifyTonSignature },
  safrapay: { normalize: normalizeSafraPayPayment, verify: verifySafraPaySignature },
  infinitepay: { normalize: normalizeInfinitePayPayment, verify: verifyInfinitePaySignature },
};
