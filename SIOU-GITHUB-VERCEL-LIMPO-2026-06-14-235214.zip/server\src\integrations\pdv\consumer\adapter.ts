import { normalizeGenericPdvPayload } from '../shared/normalize';
export const normalizeConsumerPayload = (payload: unknown, restaurantId: string) =>
  normalizeGenericPdvPayload({ payload, restaurantId, provider: 'consumer' });
