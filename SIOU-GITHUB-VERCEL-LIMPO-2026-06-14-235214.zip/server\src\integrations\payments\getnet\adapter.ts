import { normalizeGenericPaymentPayload, verifyGenericPaymentSignature } from '../shared/generic-adapter';
export const verifyGetnetSignature = verifyGenericPaymentSignature;
export const normalizeGetnetPayment = (payload: unknown, restaurantId: string) =>
  normalizeGenericPaymentPayload({ payload, restaurantId, provider: 'getnet' });
