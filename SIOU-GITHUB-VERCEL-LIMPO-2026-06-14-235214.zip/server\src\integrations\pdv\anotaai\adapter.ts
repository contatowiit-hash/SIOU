import { normalizeGenericPdvPayload } from '../shared/normalize';
export const normalizeAnotaAiPayload = (payload: unknown, restaurantId: string) =>
  normalizeGenericPdvPayload({ payload, restaurantId, provider: 'anotaai' });
