import { normalizeGenericPdvPayload } from '../shared/normalize';
export const normalizeGoomerPayload = (payload: unknown, restaurantId: string) =>
  normalizeGenericPdvPayload({ payload, restaurantId, provider: 'goomer' });
