import { normalizeGenericPaymentPayload, verifyGenericPaymentSignature } from '../shared/generic-adapter';
export const verifyStoneSignature = verifyGenericPaymentSignature;
export const normalizeStonePayment = (payload: unknown, restaurantId: string) =>
  normalizeGenericPaymentPayload({ payload, restaurantId, provider: 'stone' });
