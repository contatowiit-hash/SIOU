import { normalizeAnotaAiPayload } from './anotaai/adapter';
import { normalizeConsumerPayload } from './consumer/adapter';
import { normalizeGoomerPayload } from './goomer/adapter';
import { normalizeSaiposPayload } from './saipos/adapter';
import { normalizeSischefPayload } from './sischef/adapter';

export const pdvProviders = ['saipos', 'goomer', 'anotaai', 'sischef', 'consumer'] as const;
export type PdvProvider = (typeof pdvProviders)[number];

export const pdvAdapters: Record<PdvProvider, (payload: unknown, restaurantId: string) => ReturnType<typeof normalizeSaiposPayload>> = {
  saipos: normalizeSaiposPayload,
  goomer: normalizeGoomerPayload,
  anotaai: normalizeAnotaAiPayload,
  sischef: normalizeSischefPayload,
  consumer: normalizeConsumerPayload,
};
