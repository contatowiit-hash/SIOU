import type { IncomingMessage, ServerResponse } from 'node:http';
import { buildApp } from '../server/src/app';

export const config = {
  api: {
    bodyParser: false,
  },
};

let appPromise: ReturnType<typeof buildApp> | null = null;

export const normalizeVercelApiUrl = (url?: string) => url?.replace(/^\/api(?=\/webhooks\/)/, '') ?? '/';

const getApp = async () => {
  appPromise ??= buildApp();
  const app = await appPromise;
  await app.ready();
  return app;
};

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  req.url = normalizeVercelApiUrl(req.url);
  const app = await getApp();
  app.server.emit('request', req, res);
}
