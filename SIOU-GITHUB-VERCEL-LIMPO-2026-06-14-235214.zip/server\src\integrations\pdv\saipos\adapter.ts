import { normalizeGenericPdvPayload } from '../shared/normalize';
export const normalizeSaiposPayload = (payload: unknown, restaurantId: string) =>
  normalizeGenericPdvPayload({ payload, restaurantId, provider: 'saipos' });
